/*
 * includecpp.h
 *
 *  Created on: 2017年5月12日
 *      Author: pyt64
 */

#ifndef INCLUDECPP_H_
#define INCLUDECPP_H_

#include "complier.h"

#include <string>
#include <sstream>
#include <ctime>
#include <queue>
#include <iostream>
#include <fstream>

using namespace std;

#endif /* INCLUDECPP_H_ */
